// pages/yylist/yylist.js
Page({

 
  data: {
    array:['全糖','7分糖','5分糖','3分糖','不额外加糖'],
    arr:[
      ['冰（大杯）','少冰（大杯）','热温'],['珍珠','椰果','布丁','红豆','仙草','燕麦','西米明珠']
    ]
  },
gocart:function(){
  wx.switchTab({
    url: '../cart/cart'
  })
}
})