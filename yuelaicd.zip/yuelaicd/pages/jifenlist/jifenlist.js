Page({
  data:{
    imgUrl:[
      "https://img1.baidu.com/it/u=3864037846,168920974&fm=253&fmt=auto&app=120&f=JPEG?w=1254&h=800",
      "https://img0.baidu.com/it/u=2458506880,1727410686&fm=253&fmt=auto&app=138&f=PNG?w=478&h=274",
      "https://img1.baidu.com/it/u=2063966213,1350979892&fm=253&fmt=auto&app=138&f=JPEG?w=881&h=500"
    ],
  tablist:['9积分兑换','代金券兑换','超值兑换','限时兑换','优惠券兑换'],
  bOK: true,
  inputVal:'',
  iNum:0,

  text:'积分余额',
  lists:[
    {
      arr:[
        {src:'https://img0.baidu.com/it/u=879579274,2120096489&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500',title:'优酷视频会员月卡'},
        {src:'https://img1.baidu.com/it/u=3890185249,3122439927&fm=253&fmt=auto&app=138&f=JPEG?w=750&h=480',title:'沃优游会员月卡'},
        {src:'https://img0.baidu.com/it/u=2570464709,1951326588&fm=253&fmt=auto&app=138&f=JPEG?w=250&h=250',title:'爱奇艺会员月卡'},
       
      ]
   },
  
   {
    arr:[
      {src:'https://img0.baidu.com/it/u=3719615409,4253950266&fm=253&fmt=auto&app=138&f=JPEG?w=285&h=203',title:'10元代金券'},
      {src:'https://img0.baidu.com/it/u=679671173,1890159206&fm=253&fmt=auto&app=138&f=JPEG?w=625&h=500',title:'50元代金券'},
      {src:'https://img0.baidu.com/it/u=4291642824,1227706776&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500',title:'30元代金券'},
    
    ]
  },
  
  {
    arr:[
      {src:'https://img2.baidu.com/it/u=2638259349,1857755886&fm=253&fmt=auto&app=138&f=JPEG?w=600&h=500',title:'小礼盒'},
      {src:'https://img0.baidu.com/it/u=1957179614,2123135973&fm=253&fmt=auto&app=138&f=JPEG?w=900&h=500',title:'惊喜礼品'},
      {src:'https://img2.baidu.com/it/u=133400764,1765110002&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500',title:'大礼包'},
   
    ]
  },
  {
    arr:[
      {src:'https://img1.baidu.com/it/u=3651909281,3400892211&fm=253&fmt=auto&app=120&f=JPEG?w=521&h=500',title:'保温杯'},
      {src:'https://img1.baidu.com/it/u=1467888615,3719453973&fm=253&fmt=auto&app=138&f=JPEG?w=591&h=500',title:'礼袋'},
      {src:'https://img2.baidu.com/it/u=406723472,556562280&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500',title:'礼品杯'},
     
    ]
  },
  {
    arr:[
      {src:'https://img0.baidu.com/it/u=2119069497,65670169&fm=253&fmt=auto&app=138&f=GIF?w=658&h=312',title:'20元优惠券'},
      {src:'https://img2.baidu.com/it/u=1665598068,1119911165&fm=253&fmt=auto&app=138&f=JPEG?w=790&h=300',title:'30元优惠券'},
      {src:'https://img0.baidu.com/it/u=3894228901,1618999274&fm=253&fmt=auto&app=138&f=JPEG?w=658&h=312',title:'40元优惠券'},
     
    ]
  },
  
  {
    arr:[
      {src:'https://img2.baidu.com/it/u=3671634923,803835883&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=281',title:'小保底yyds',time:'20220901',content:'七种元素神灵信仰交汇的幻想世界提瓦特'},
      {src:'https://img2.baidu.com/it/u=899518420,37042250&fm=253&fmt=auto&app=120&f=JPEG?w=580&h=312',title:'十连出金',time:'20220901',content:'七种元素神灵信仰交汇的幻想世界提瓦特'},
      {src:'https://img1.baidu.com/it/u=1405641280,2303180906&fm=253&fmt=auto&app=138&f=JPG?w=600&h=329',title:'歪歪歪',time:'2022090',content:'七种元素神灵信仰交汇的幻想世界提瓦特'},
  
    ]
  },
  
  {
    arr:[
      {src:'https://img1.baidu.com/it/u=1029647375,648698728&fm=253&fmt=auto&app=138&f=JPEG?w=707&h=500',title:'小保底yyds',time:'20220901',content:'七种元素神灵信仰交汇的幻想世界提瓦特'},
      {src:'https://img1.baidu.com/it/u=474661950,1044687758&fm=253&fmt=auto&app=120&f=JPEG?w=393&h=499',title:'十连出金',time:'20220901',content:'七种元素神灵信仰交汇的幻想世界提瓦特'},
      {src:'https://img1.baidu.com/it/u=3193919699,1593891642&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500',title:'歪歪歪',time:'2022090',content:'七种元素神灵信仰交汇的幻想世界提瓦特'},
     
    ]
  },
  
  {
    arr:[
      {src:'https://img1.baidu.com/it/u=2824358069,1289258018&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500',title:'小保底yyds',time:'20220901',content:'七种元素神灵信仰交汇的幻想世界提瓦特'},
      {src:'https://img1.baidu.com/it/u=1968474161,2937758616&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500',title:'十连出金',time:'20220901',content:'七种元素神灵信仰交汇的幻想世界提瓦特'},
      {src:'https://img0.baidu.com/it/u=343501587,3479276228&fm=253&fmt=auto&app=138&f=JPEG?w=499&h=281',title:'歪歪歪',time:'2022090',content:'七种元素神灵信仰交汇的幻想世界提瓦特'},
    
    ]
  },
  
  ]
  },
  
   click: function(){
      if(this.data.bOK === true){
          this.setData({
            text:"剩余10积分", 
          })
          this.setData({
            bOK: false
          })
      } else {
        this.setData({
          text:"积分余额", 
        })
        this.setData({
          bOK: true
        })
      }

      //  this.setData({
      //   text:"剩余10积分", 
      // })
    },
 
  
  getval:function(e){
    this.setData({
      inputVal:e.detail.value
    })
  },
  onReady:function(){
    this.videoContext=wx.createVideoContext('myvideo');
  },
  sendDanmu:function(){
    this.videoContext.sendDanmu({
      text:this.data.inputVal,
      color:'#c00'
    })
  },
  fntab:function(e){
    this.setData({
      iNum:e.currentTarget.dataset.idx
    })
  }
  })
  